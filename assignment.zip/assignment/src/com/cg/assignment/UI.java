package com.cg.assignment;

import java.util.Scanner;



public class UI {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		Account[] accounts= new Account[10];
		Loan[] loans= new Loan[10];
		Transaction transactions= new Transaction();
		Loan loan= new Loan();
	
		int choice=0;
		String cont=null;
		
		do {
			
			do {
					System.out.println("1. Create Account 2. Login");
					choice=scanner.nextInt();
					
				switch (choice) {
				case 1:

					String accountName=null;
					String accountId=null;
					
					int i=0;
					{
						System.out.println("Account Name: ");
					 accountName=scanner.next();
					}
					;
					System.out.println("Address: ");
					String address=scanner.next();
					System.out.println("Enter deposit ammount: ");
					double depositAmount=scanner.nextDouble();
					String loanType=null;
					double loanAmount=0;
					accountId=getAccountId();
					for(i=0;i<10;i++) {
						accounts[i]=new Account(accountId,accountName,address,depositAmount);
					}
					System.out.println("Account created with accountId: "+accountId);
					
					break;
				case 2:
					
					String accountId1=null;
					int choice2=0;
					Account acc1=null;
					{
						
					System.out.println("Enter accountId: ");
					
					 accountId1=scanner.next();
					};
					for(int j=0;j<10;j++) {
						if(accountId1.equals(accounts[j].getAccountId())) {
							acc1=accounts[j];}
						
							else{
								System.out.println("Account not exists");
								break;
								}
							}
					
					do {
					System.out.println("1. Account Details 2. Loan 3. Transaction");
					choice2=scanner.nextInt();
					switch (choice2) {
					case 1:
						transactions.showDetails(acc1);
						
						break;
						
				
			}
				}while(!(choice>=1&&choice<=3));
				
			
			

				
				}
		System.out.println("Please enter yes or no: ");
		
		cont=scanner.next();}
		
		while(!(choice>=1&&choice<=2));
		
		
		}while(cont.equalsIgnoreCase("yes"));

	}

	
	private static String getAccountId() {
		
		
		long accountNo=(long)(Math.random()*10000000);
		String actId=Long.toString(accountNo);
		actId=actId+"-ASDF";
		return actId;
	}

}
