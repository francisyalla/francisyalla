package com.cg.assignment;

public class Account {
	private String accountId;
	private String accountName;
	private String address;
	private double depositAmmount;

	public Account(String accountId, String accountName, String address, double depositeAmmount) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
		this.address = address;
		this.depositAmmount = depositeAmmount;
	}
	public Account() {

	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getDepositAmmount() {
		return depositAmmount;
	}
	public void setDepositAmmount(double depositAmmount) {
		this.depositAmmount = depositAmmount;
	}
	public void getDetails() {
	}
	public void showDetails(Account account) {
		System.out.println(account.getAccountId());
		System.out.println(account.getAccountName());
		System.out.println(account.getAddress());
		System.out.println(account.getDepositAmmount());
	}
	

}
